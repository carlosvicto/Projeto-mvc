
package View;

import Controller.ControleProduto;
import Model.Produto;
import javax.swing.JOptionPane;


public class jfCadastro extends javax.swing.JFrame {

    
    ControleProduto controle= new ControleProduto();
    public jfCadastro() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jtfProduto = new javax.swing.JTextField();
        jtfPreço = new javax.swing.JTextField();
        jbCadastrar = new javax.swing.JButton();
        jtfValidade = new javax.swing.JTextField();
        jbBuscar = new javax.swing.JButton();
        jbExcluir = new javax.swing.JButton();
        jbAlt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 51));
        jLabel2.setText("Cadastro de Produtos");

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel1.setText("Nome do Produto:");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel3.setText("Preço:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel4.setText("Data de Validade:");

        jtfProduto.setForeground(new java.awt.Color(204, 0, 51));

        jtfPreço.setForeground(new java.awt.Color(204, 0, 51));

        jbCadastrar.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jbCadastrar.setForeground(new java.awt.Color(204, 0, 51));
        jbCadastrar.setText("Cadastrar");
        jbCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarActionPerformed(evt);
            }
        });

        jtfValidade.setForeground(new java.awt.Color(204, 0, 51));

        jbBuscar.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jbBuscar.setForeground(new java.awt.Color(204, 0, 51));
        jbBuscar.setText("Buscar");
        jbBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbBuscarActionPerformed(evt);
            }
        });

        jbExcluir.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jbExcluir.setForeground(new java.awt.Color(204, 0, 51));
        jbExcluir.setText("Excluir");
        jbExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbExcluirActionPerformed(evt);
            }
        });

        jbAlt.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jbAlt.setForeground(new java.awt.Color(204, 0, 51));
        jbAlt.setText("Atualizar");
        jbAlt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAltActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 49, Short.MAX_VALUE)
                .addComponent(jbCadastrar)
                .addGap(18, 18, 18)
                .addComponent(jbBuscar)
                .addGap(32, 32, 32)
                .addComponent(jbAlt)
                .addGap(36, 36, 36)
                .addComponent(jbExcluir)
                .addGap(23, 23, 23))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtfPreço, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtfValidade, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtfProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jbAlt, jbBuscar, jbCadastrar, jbExcluir});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jtfProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtfPreço, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfValidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbCadastrar)
                    .addComponent(jbBuscar)
                    .addComponent(jbAlt)
                    .addComponent(jbExcluir))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jLabel1, jLabel3, jLabel4});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jbAlt, jbBuscar, jbCadastrar, jbExcluir});

        setSize(new java.awt.Dimension(546, 360));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
private void limpar(){
    jtfProduto.setText("");
    jtfPreço.setText("");
    jtfValidade.setText("");
}
    private void jbCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarActionPerformed
        // TODO add your handling code here:
        
        String nomePro = jtfProduto.getText();
        double preçoPro = Double.parseDouble(jtfPreço.getText());
        String data = jtfValidade.getText();
        controle.cadastrar(nomePro,data,preçoPro);
        JOptionPane.showMessageDialog(null,"O produto foi cadastrado com sucesso!");
        limpar();
    }//GEN-LAST:event_jbCadastrarActionPerformed

    private void jbBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbBuscarActionPerformed
        // TODO add your handling code here:
          String buscaNome = jtfProduto.getText();
          Produto pro = controle.buscar(buscaNome);
          if(pro == null){
              JOptionPane.showMessageDialog(this,"Produto não pôde ser cadastrado com sucesso, tente novamente!");
          }else{
              jtfProduto.setText(pro.getNome());
              jtfPreço.setText(String.valueOf(pro.getPreço()));
              jtfValidade.setText(pro.getData());
          }       
    }//GEN-LAST:event_jbBuscarActionPerformed

    private void jbAltActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAltActionPerformed
    // TODO add your handling code here:
    String nome = jtfProduto.getText();
    String data = jtfValidade.getText();
    double preço = Double.parseDouble(jtfPreço.getText());
    controle.atualizar(nome, preço, data);
    limpar();
    JOptionPane.showMessageDialog(this, "O produto foi atualizado com sucesso!");
    }//GEN-LAST:event_jbAltActionPerformed

    private void jbExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbExcluirActionPerformed
        // TODO add your handling code here:
    String nome = jtfProduto.getText();
    String data = jtfValidade.getText();
    double preço = Double.parseDouble(jtfPreço.getText());
    controle.excluir(nome);
    limpar();
    }//GEN-LAST:event_jbExcluirActionPerformed

   
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JButton jbAlt;
    private javax.swing.JButton jbBuscar;
    private javax.swing.JButton jbCadastrar;
    private javax.swing.JButton jbExcluir;
    private javax.swing.JTextField jtfPreço;
    private javax.swing.JTextField jtfProduto;
    private javax.swing.JTextField jtfValidade;
    // End of variables declaration//GEN-END:variables
}
