/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Produto;

/**
 *
 * @author aluno
 */
public class ControleProduto {
    Produto[] listaDeProdutos;
    Produto pro = null;
    int i = 0;
    int cod = 0;
    boolean achou;
public ControleProduto(){
    listaDeProdutos = new Produto[5];
    listaDeProdutos[0]= new Produto();
    listaDeProdutos[1] = new Produto();
    listaDeProdutos[2] = new Produto();
    listaDeProdutos[3] = new Produto();
    listaDeProdutos[4] = new Produto();
}
    public void cadastrar(String nome,String data,Double preço) {
        cod++;
        listaDeProdutos[i].setNome(nome);
        listaDeProdutos[i].setData(data);
        listaDeProdutos[i].setPreço(preço);
        listaDeProdutos[i].setCódigo(cod);
        i++;
    }
    public Produto buscar(String proNome){
        Produto pro = null;
        for (int i = 0;i<listaDeProdutos.length;i++){
            if(listaDeProdutos[i].getNome().equals(proNome)){
                pro = listaDeProdutos[i];
            }
        }
            return pro;
    }
    public void atualizar(String nomeAlt , double preçoAlt , String dataAlt) {
        for( int i = 0; i<listaDeProdutos.length;i++){
            if(listaDeProdutos[i].getNome().equals(nomeAlt)) {
                listaDeProdutos[i].setNome(nomeAlt);
                listaDeProdutos[i].setData(dataAlt);
                listaDeProdutos[i].setPreço(preçoAlt);
                break;
            }
        }
        
    }
    public void excluir(String nomeExcluir){
        for(int i = 0; i<listaDeProdutos.length;i++){
            String nome = listaDeProdutos[i].getNome();
            if (nome.equals(nomeExcluir)){
                listaDeProdutos[i].setData("");
                listaDeProdutos[i].setNome("");
                listaDeProdutos[i].setPreço(0);
            }
        }
    }
    
}
